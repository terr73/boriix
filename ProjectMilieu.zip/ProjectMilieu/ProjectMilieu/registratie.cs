﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;


namespace ProjectMilieu
{
    public partial class registratie : Form
    {
        public registratie()
        {
            InitializeComponent();
        }
        static string connectstr = "datasource=localhost; username=root; password=; database=milieu";

        MySqlConnection DBconnect = new MySqlConnection(connectstr);

        public void txtNaam_TextChanged(object sender, EventArgs e)
        {

        }




        private void btnVoltooi_Click(object sender, EventArgs e)
        {



            try

            {

                DBconnect.Open();



                string qry = "INSERT INTO `gebruikers` (`ID`, `Naam`, `Wachtwoord`) VALUES (NULL, '" + txtNaam.Text + "', '" + txtWachtwoord.Text + "')";

                MySqlDataAdapter SDA = new MySqlDataAdapter(qry, DBconnect);

                SDA.SelectCommand.ExecuteNonQuery();

                DBconnect.Close();

                MessageBox.Show("Succes");
                Form2 myForm = new Form2();
                this.Hide();
                var newwindow = new Form2();

                newwindow.Show();
            }

            catch

            {

                MessageBox.Show("Niet ok");

            }

            DBconnect.Close();

        }



        private void button2_Click(object sender, EventArgs e)

        {

            DBconnect.Open();

            string qry = "SELECT * FROM `gebruikers` WHERE 1";

            MySqlDataAdapter SDA = new MySqlDataAdapter(qry, DBconnect);

            DataTable dt = new DataTable();

            SDA.Fill(dt);

            

            DBconnect.Close();

        }



        private void button3_Click(object sender, EventArgs e)

        {

            DBconnect.Open();

            string qry = "SELECT * FROM `gebruikers` WHERE 1";

            //MySqlDataAdapter SDA = new MySqlDataAdapter(qry, DBconnect);

            MySqlCommand cmd = new MySqlCommand(qry, DBconnect);

            MySqlDataReader dr = cmd.ExecuteReader();

           

            DBconnect.Close();



        }


    }

}


