﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjectMilieu
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 myForm = new Form7();
            this.Hide();
            var newwindow = new Form7();

            newwindow.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 myForm = new Form5();
            this.Hide();
            var newwindow = new Form5();

            newwindow.Show();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM milieu.gebruikers", connection);
                connection.Open();
                DataSet ds = new DataSet();
                adapter.Fill(ds, "gebruikers");
                dataGridView1.DataSource = ds.Tables["gebruikers"];
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
    }