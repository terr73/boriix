﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMilieu
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnStoring_Click(object sender, EventArgs e)
        {
            Form4 myForm = new Form4();
            this.Hide();
            var newwindow = new Form4();

            newwindow.Show();
        }

        private void btnMelding_Click(object sender, EventArgs e)
        {
            Form3 myForm = new Form3();
            this.Hide();
            var newwindow = new Form3();

            newwindow.Show();
        }

        private void lblUser_Click(object sender, EventArgs e)
        {

        }
    }
}
