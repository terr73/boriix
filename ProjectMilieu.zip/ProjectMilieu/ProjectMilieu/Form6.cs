﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjectMilieu
{
    public partial class Form6 : Form
    {
        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        MySqlCommand command;
        MySqlDataReader mdr;
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            string selectQuery = "SELECT * FROM milieu.meldingen WHERE id=" + int.Parse(txtID.Text);
            command = new MySqlCommand(selectQuery, connection);
            mdr = command.ExecuteReader();
            if (mdr.Read())
            {
                txtMelding.Text = mdr.GetString("Melding");
                txtDatum.Text = mdr.GetString("Datum");
                
            }
            else
            {
                txtID.Text = "";
                txtMelding.Text = "";
                txtDatum.Text = "";
                MessageBox.Show("Geen data voor deze ID");
            }
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 myForm = new Form7();
            this.Hide();
            var newwindow = new Form7();

            newwindow.Show();
        }
    }
}


       