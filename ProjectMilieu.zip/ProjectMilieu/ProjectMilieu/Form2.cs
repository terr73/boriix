﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProjectMilieu
{
    public partial class Form2 : Form
    {
        static string connectstr = "datasource=localhost; username=root; password=; database=milieu";

        MySqlConnection DBconnect = new MySqlConnection(connectstr);
        public Form2()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            DBconnect.Open();

           
                


                string qry = "select * from gebruikers where username=@Naam and password=@Wachtwoord ";

            MySqlDataAdapter SDA = new MySqlDataAdapter(qry, DBconnect);

            MySqlCommand cmd = new MySqlCommand(qry, DBconnect);

           



            DBconnect.Close();
                System.Windows.Forms.MessageBox.Show("U bent succesvol ingelogd");
                Form5 myForm = new Form5();
                this.Hide();
                var newwindow = new Form5();

                newwindow.Show();
            
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtUser.Text = "";
            txtPass.Text = "";
        }

        public void txtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            registratie myForm = new registratie();
            this.Hide();
            var newwindow = new registratie();

            newwindow.Show();
        }
    }
}
