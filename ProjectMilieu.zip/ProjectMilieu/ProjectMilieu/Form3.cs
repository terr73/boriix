﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjectMilieu
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        static string connectstr = "datasource=localhost; username=root; password=; database=milieu";

        MySqlConnection DBconnect = new MySqlConnection(connectstr);

        private void button1_Click(object sender, EventArgs e)
        {

     dataGridView1.Rows.Add(txtMelding.Text, txtDatum.Text);

            try

            {

                DBconnect.Open();



                string qry = "INSERT INTO `meldingen` (`ID`, `Melding`, `Datum`) VALUES (NULL, '" + txtMelding.Text + "', '" + txtDatum.Text + "')";

                MySqlDataAdapter SDA = new MySqlDataAdapter(qry, DBconnect);

                SDA.SelectCommand.ExecuteNonQuery();

                DBconnect.Close();

                MessageBox.Show("Succes");

            }

            catch

            {

                MessageBox.Show("Niet ok");

            }

            DBconnect.Close();

        }



      



        private void button3_Click(object sender, EventArgs e)

        {

            DBconnect.Open();

            string qry = "SELECT * FROM `gebruikers` WHERE 1";

            //MySqlDataAdapter SDA = new MySqlDataAdapter(qry, DBconnect);

            MySqlCommand cmd = new MySqlCommand(qry, DBconnect);

            MySqlDataReader dr = cmd.ExecuteReader();



            DBconnect.Close();



        }


    

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 myForm = new Form4();
            this.Hide();
            var newwindow = new Form4();

            newwindow.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnZoek_Click(object sender, EventArgs e)
        {
            Form6 myForm = new Form6();
            this.Hide();
            var newwindow = new Form6();

            newwindow.Show();
        }
    }
}
